/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service.Implemantation;

import Dao.UserDao;
import Model.SessionManager;
import Service.UserInterface;
import java.rmi.RemoteException;
import Model.UserDTO;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.mail.*;
import javax.mail.internet.*;


public class UserServiceImpl extends UnicastRemoteObject implements UserInterface {
    private UserDao userDao;
    private final Map<String, String> otpStore = new ConcurrentHashMap<>();
    private final Map<String, Long> otpExpiryStore = new ConcurrentHashMap<>();
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    private static final int OTP_EXPIRY_TIME_MINUTES = 5;

    public UserServiceImpl() throws RemoteException {
        userDao = new UserDao();
        startOtpCleanupTask();
    }

    

    @Override
    public UserDTO login(String username, String password) throws RemoteException {
        return userDao.getUserByUsernameAndPassword(username, password);
    }

    @Override
    public boolean sendOtp(String username, String password) throws RemoteException {
        UserDTO user = userDao.getUserByUsernameAndPassword(username, password);
        if (user != null) {
            String otp = generateOtp();
            sendOtpToUser(user, otp);
            saveOtp(username, otp);
            return true;
        }
        return false;
    }

    @Override
    public UserDTO loginWithOtp(String username, String password, String otp) throws RemoteException {
        UserDTO user = userDao.getUserByUsernameAndPassword(username, password);
        if (user != null && verifyOtp(username, otp)) {
            return user;
        }
        return null;
    }

    private String generateOtp() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000);
        return String.valueOf(otp);
    }

    private void sendOtpToUser(UserDTO user, String otp) {
        String to = user.getEmail();
        String from = "yvannystrong@gmail.com";
        String host = "smtp.gmail.com";

        Properties properties = System.getProperties();
        properties.setProperty("mail.smtp.host", host);
        properties.setProperty("mail.smtp.port", "587");
        properties.setProperty("mail.smtp.auth", "true");
        properties.setProperty("mail.smtp.starttls.enable", "true");

        Session session = Session.getDefaultInstance(properties, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("yvannystrong@gmail.com", "kslupyxkszxpzfje");
            }
        });

        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            message.setSubject("Your OTP Code");
            message.setText("Dear " + user.getUsername() + ",\n\nYour OTP code is: " + otp + "\n\nBest regards,\nYour Company");
            Transport.send(message);
            System.out.println("OTP email sent successfully...");
         } catch (MessagingException mex) {
                            mex.printStackTrace();
                            System.out.println("Reka message Wapiiii. " + mex);
                        }
    }



    private void saveOtp(String username, String otp) {
        otpStore.put(username, otp);
        otpExpiryStore.put(username, System.currentTimeMillis() + OTP_EXPIRY_TIME_MINUTES * 60 * 1000);
    }

    private boolean verifyOtp(String username, String otp) {
        String storedOtp = otpStore.get(username);
        Long expiryTime = otpExpiryStore.get(username);

        if (storedOtp != null && storedOtp.equals(otp) && expiryTime != null && System.currentTimeMillis() <= expiryTime) {
            otpStore.remove(username);
            otpExpiryStore.remove(username);
            return true;
        }
        return false;
    }

    private void startOtpCleanupTask() {
        scheduler.scheduleAtFixedRate(() -> {
            long currentTime = System.currentTimeMillis();
            otpExpiryStore.entrySet().removeIf(entry -> entry.getValue() <= currentTime);
            otpStore.keySet().removeIf(username -> !otpExpiryStore.containsKey(username));
        }, 1, 1, TimeUnit.MINUTES);
    }

    @Override
    public int signUp(UserDTO user) throws RemoteException {
        return userDao.saveUser(user);
    }

    @Override
    public List<UserDTO> getAllUsers() {
        try {
            return userDao.getAllUsers();
        } catch (Exception e) {
        }
    return null;      }

    @Override
    public int updateUser(UserDTO userD) throws RemoteException {
        try {
            return userDao.updateUser(userD);
        } catch (Exception e) {
        }
    return 0;
    }

    @Override
    public int deleteUser(UserDTO userD) throws RemoteException {
        try {
            return userDao.deleteUser(userD);
        } catch (Exception e) {
        }
    return 0;
    }
}
