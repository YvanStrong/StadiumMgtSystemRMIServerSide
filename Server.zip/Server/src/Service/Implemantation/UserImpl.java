package Service.Implemantation;

import Dao.UserDao;
import Model.UserDTO;
import Model.SessionManager;
import Service.UserInterface;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class UserImpl extends UnicastRemoteObject implements UserInterface {
    private final UserDao userDao = new UserDao();
    private final Map<String, String> otpStore = new ConcurrentHashMap<>();
    private final Map<String, Long> otpExpiryStore = new ConcurrentHashMap<>();
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    private static final int OTP_EXPIRY_TIME_MINUTES = 5;

    public UserImpl() throws RemoteException {
        super();
    }

    @Override
    public int signUp(UserDTO user) throws RemoteException {
        return userDao.saveUser(user);
    }

    @Override
    public UserDTO login(String username, String password) throws RemoteException {
        UserDTO user = userDao.getUserByUsernameAndPassword(username, password);
        if (user != null) {
            SessionManager.setCurrentUser(user);
            System.out.println("User logged in: " + user.getUsername()); // Debug statement
        } else {
            System.out.println("Login failed for user: " + username); // Debug statement
        }
        return user;
    }
    
    @Override
    public boolean sendOtp(String username, String password) throws RemoteException {
        UserDTO user = userDao.getUserByUsernameAndPassword(username, password);
        if (user != null) {
            String otp = generateOtp();
            sendOtpToUser(user, otp);
            return userDao.saveOtp(username, otp);
        }
        return false;
    }

    @Override
    public UserDTO loginWithOtp(String username, String password, String otp) throws RemoteException {
        UserDTO user = userDao.getUserByUsernameAndPassword(username, password);
        if (user != null && userDao.verifyOtp(username, otp)) {
            return user;
        }
        return null;
    }

    private String generateOtp() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000);
        return String.valueOf(otp);
    }

    private void sendOtpToUser(UserDTO user, String otp) {
        
    }
    private void saveOtp(String username, String otp) {
        otpStore.put(username, otp);
        otpExpiryStore.put(username, System.currentTimeMillis() + OTP_EXPIRY_TIME_MINUTES * 60 * 1000);
    }

    private boolean verifyOtp(String username, String otp) {
        String storedOtp = otpStore.get(username);
        Long expiryTime = otpExpiryStore.get(username);

        if (storedOtp != null && storedOtp.equals(otp) && expiryTime != null && System.currentTimeMillis() <= expiryTime) {
            otpStore.remove(username);
            otpExpiryStore.remove(username);
            return true;
        }
        return false;
    }

    private void startOtpCleanupTask() {
        scheduler.scheduleAtFixedRate(() -> {
            long currentTime = System.currentTimeMillis();
            otpExpiryStore.entrySet().removeIf(entry -> entry.getValue() <= currentTime);
            otpStore.keySet().removeIf(username -> !otpExpiryStore.containsKey(username));
        }, 1, 1, TimeUnit.MINUTES);
    }

    @Override
    public List<UserDTO> getAllUsers() {
        try {
            return userDao.getAllUsers();
        } catch (Exception e) {
        }
    return null;      }

    @Override
    public int updateUser(UserDTO userD) throws RemoteException {
        try {
            return userDao.updateUser(userD);
        } catch (Exception e) {
        }
    return 0;
    }

    @Override
    public int deleteUser(UserDTO userD) throws RemoteException {
        try {
            return userDao.deleteUser(userD);
        } catch (Exception e) {
        }
    return 0;
    }
}
