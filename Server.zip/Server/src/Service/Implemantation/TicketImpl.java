package Service.Implemantation;

import Dao.TicketDao;
import Dao.HibernateUtil;
import Model.Event;
import Model.SessionManager;
import Model.Ticket;
import Model.TicketDTO;
import Model.User;
import Model.UserDTO;
import Service.TicketInterface;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

public class TicketImpl extends UnicastRemoteObject implements TicketInterface {
    private final TicketDao dao = new TicketDao();

    public TicketImpl() throws RemoteException {
        super();
    }

@Override
public int createTicket(TicketDTO ticketDTO) throws RemoteException {
    Transaction transaction = null;
    try {Session session = HibernateUtil.getSessionFactory().openSession();
        transaction = session.beginTransaction();

        // List all users for debugging
        List<UserDTO> users = session.createQuery("FROM UserDTO").list();
        for (UserDTO u : users) {
            System.out.println("User in DB: " + u.getId() + ", " + u.getUsername());
        }

        // Retrieve User entity
        int userId = SessionManager.getLoggedInUserId();
        System.out.println("Logged in user ID: " + userId); // Debug statement
        User user = (User) session.get(User.class, userId);
        if (user == null) {
            throw new Exception("User not found");
        }

        // Retrieve Event entity
        Event event = (Event) session.get(Event.class, ticketDTO.getEventId());
        if (event == null) {
            throw new Exception("Event not found");
        }

        Ticket ticket = new Ticket();
        ticket.setEvent(event);
        ticket.setUser(user);
        ticket.setSeatNumber(Integer.parseInt(ticketDTO.getSeatNumber()));
        ticket.setPrice(ticketDTO.getPrice());

        session.save(ticket);
        transaction.commit();
        return 1;
    } catch (Exception ex) {
        if (transaction != null) {
            transaction.rollback();
        }
        ex.printStackTrace();
        return 0;
    }
}

    @Override
    public List<TicketDTO> retrieveTickets() throws RemoteException {
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            List<Ticket> tickets = session.createQuery("from Ticket").list();

            List<TicketDTO> ticketDTOs = new ArrayList<>();
            for (Ticket ticket : tickets) {
                TicketDTO dto = new TicketDTO(
                    ticket.getId(),
                    ticket.getEvent().getId(),
                    ticket.getUser().getId(),
                    String.valueOf(ticket.getSeatNumber()),
                    ticket.getPrice()
                );
                ticketDTOs.add(dto);
            }
            return ticketDTOs;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    @Override
    public int updateTicket(TicketDTO ticketDTO) throws RemoteException {
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            transaction = session.beginTransaction();

            Ticket ticket = (Ticket) session.get(Ticket.class, ticketDTO.getId());
            if (ticket != null) {
                // Retrieve User entity
                User user = (User) session.get(User.class, ticketDTO.getUserId());
                if (user == null) {
                    throw new Exception("User not found");
                }

                // Retrieve Event entity
                Event event = (Event) session.get(Event.class, ticketDTO.getEventId());
                if (event == null) {
                    throw new Exception("Event not found");
                }

                ticket.setEvent(event);
                ticket.setUser(user);
                ticket.setSeatNumber(Integer.parseInt(ticketDTO.getSeatNumber()));
                ticket.setPrice(ticketDTO.getPrice());
                session.update(ticket);
                transaction.commit();
                return 1;
            } else {
                return 0;
            }
        } catch (Exception ex) {
            if (transaction != null) {
                transaction.rollback();
            }
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int deleteTicket(TicketDTO ticketDTO) throws RemoteException {
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            transaction = session.beginTransaction();

            Ticket ticket = (Ticket) session.get(Ticket.class, ticketDTO.getId());
            if (ticket != null) {
                session.delete(ticket);
                transaction.commit();
                return 1;
            } else {
                return 0;
            }
        } catch (Exception ex) {
            if (transaction != null) {
                transaction.rollback();
            }
            ex.printStackTrace();
            return 0;
        }
    }
}
