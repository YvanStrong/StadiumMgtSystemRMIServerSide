package Service.Implemantation;

import Dao.EventDao;
import Dao.HibernateUtil;
import Model.Event;
import Model.EventDTO;
import Model.Stadium;
import Model.StadiumDTO;
import Service.EventInterface;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

public class EventImpl extends UnicastRemoteObject implements EventInterface {

    private final EventDao dao = new EventDao();

    public EventImpl() throws RemoteException {
        super();
    }

    @Override
    public int addEvent(EventDTO eventDTO) throws RemoteException {
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession() ;
            transaction = session.beginTransaction();
            Event event = new Event();
            event.setName(eventDTO.getName());
            event.setDate(eventDTO.getDate());
            event.setLocation(eventDTO.getLocation());
            session.save(event);
            transaction.commit();
            return 1;
        } catch (Exception ex) {
            if (transaction != null) {
                transaction.rollback();
            }
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int updateEvent(EventDTO eventDTO) throws RemoteException {
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            transaction = session.beginTransaction();
            Event event = (Event) session.get(Event.class, eventDTO.getId());
            if (event != null) {
                event.setName(eventDTO.getName());
                event.setDate(eventDTO.getDate());
                event.setLocation(eventDTO.getLocation());
                session.update(event);
                transaction.commit();
                return 1;
            } else {
                return 0;
            }
        } catch (Exception ex) {
            if (transaction != null) {
                transaction.rollback();
            }
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int deleteEvent(EventDTO eventDTO) throws RemoteException {
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
               
            transaction = session.beginTransaction();
            Event event = (Event) session.get(Event.class, eventDTO.getId());
            if (event != null) {
                session.delete(event);
                transaction.commit();
                return 1;
            } else {
                return 0;
            }
        } catch (Exception ex) {
            if (transaction != null) {
                transaction.rollback();
            }
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public List<EventDTO> retrieveEvents() throws RemoteException {
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            List<Event> events = session.createQuery("from Event").list();

            // Convert Event entities to EventDTOs
            List<EventDTO> eventDTOs = new ArrayList<>();
            for (Event event : events) {
                EventDTO dto = new EventDTO(event.getId(), event.getName(), event.getDate(), event.getLocation());
                eventDTOs.add(dto);
            }
            return eventDTOs;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    @Override
    public List<StadiumDTO> retrieveStadiums() throws RemoteException {
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            List<Stadium> stadiums = session.createQuery("from Stadium").list();

            List<StadiumDTO> stadiumDTOs = new ArrayList<>();
            for (Stadium stadium : stadiums) {
                StadiumDTO dto = new StadiumDTO(stadium.getId(), stadium.getName(), stadium.getLocation());
                stadiumDTOs.add(dto);
            }
            return stadiumDTOs;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
}
