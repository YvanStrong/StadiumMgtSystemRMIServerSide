/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service.Implemantation;

import Dao.StadiumDao;
import Model.Stadium;
import Service.StadiumInteface;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

/**
 *
 * @author Yvan Strong
 */
public class StadiumImpl extends UnicastRemoteObject implements StadiumInteface{
    
private final StadiumDao dao=new StadiumDao();
    public StadiumImpl() throws RemoteException {
        super();
    }

    @Override
    public int addStadium(Stadium stadium) throws RemoteException {
       try {
            return dao.addStadium(stadium);
        } catch (Exception e) {
        }
    return 0;
    }

    @Override
    public Stadium getStadium(int id) throws RemoteException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Stadium> getAllStadiums() throws RemoteException {
        try {
            return dao.retrieveStadiums();
        } catch (Exception e) {
        }
    return null;    }

    @Override
    public int updateStadium(Stadium stadium) throws RemoteException {
        try {
            return dao.updateStadium(stadium);
        } catch (Exception e) {
        }
    return 0;
    }

    @Override
    public int deleteStadium(Stadium stadium) throws RemoteException {
        try {
            return dao.deleteStadium(stadium);
        } catch (Exception e) {
        }
    return 0;
    }

   
    
}
