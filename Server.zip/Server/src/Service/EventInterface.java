package Service;

import Model.EventDTO;
import Model.StadiumDTO;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface EventInterface extends Remote {
    int addEvent(EventDTO event) throws RemoteException;
    int updateEvent(EventDTO event) throws RemoteException;
    int deleteEvent(EventDTO event) throws RemoteException;
    List<EventDTO> retrieveEvents() throws RemoteException;
    List<StadiumDTO> retrieveStadiums() throws RemoteException;
}
