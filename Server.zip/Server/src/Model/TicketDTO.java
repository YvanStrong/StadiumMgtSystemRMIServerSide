package Model;

import java.io.Serializable;

public class TicketDTO implements Serializable {
    private int id;
    private int eventId;
    private int userId;
    private String seatNumber;
    private double price;

    // Default constructor
    public TicketDTO() {
    }

    // Parameterized constructor
    public TicketDTO(int id, int eventId, int userId, String seatNumber, double price) {
        this.id = id;
        this.eventId = eventId;
        this.userId = userId;
        this.seatNumber = seatNumber;
        this.price = price;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
