/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Service.Implemantation.EventImpl;
import Service.Implemantation.StadiumImpl;
import Service.Implemantation.TicketImpl;
import Service.Implemantation.UserImpl;
import Service.Implemantation.UserServiceImpl;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import javax.mail.MessagingException;
import javax.mail.*;
import javax.mail.internet.*;

/**
 *
 * @author Yvan Strong
 */
public class Server {
    public static void main(String[] args) {
        try {
            System.setProperty("java.rmi.server.hostname","127.0.0.1");
            Registry registry = LocateRegistry.createRegistry(5000); // Use port 5000
            registry.bind("stadium", new StadiumImpl());
            registry.bind("ticket", new TicketImpl());
            registry.bind("event", new EventImpl());
//            registry.bind("users", new UserServiceImpl());
            registry.bind("users", new UserImpl());
            System.out.println("Server started... and Running on port 5000");
        } catch (Exception  e) {
            e.printStackTrace();
        }
    }
    
}
