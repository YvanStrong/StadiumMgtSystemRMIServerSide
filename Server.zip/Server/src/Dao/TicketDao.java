/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;
import Model.Ticket;

public class TicketDao {

    public TicketDao() {
    }

    // Method to retrieve all tickets
    public List<Ticket> retrieveTickets() {
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            List<Ticket> query = session.createQuery("from Ticket").list();
            return query;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    // Method to delete a ticket
    public int deleteTicket(Ticket ticket) {
        Transaction tx = null;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            session.delete(ticket);
            tx.commit();
            return 1;
        } catch (Exception ex) {
            if (tx != null) tx.rollback();
            ex.printStackTrace();
            return 0;
        }
    }

    // Method to update a ticket
    public int updateTicket(Ticket ticket) {
        Transaction tx = null;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            session.update(ticket);
            tx.commit();
            return 1;
        } catch (Exception ex) {
            if (tx != null) tx.rollback();
            ex.printStackTrace();
            return 0;
        }
    }

    // Method to add a ticket
    public int createTicket(Ticket ticket) {
        Transaction tx = null;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            session.save(ticket);
            tx.commit();
            return 1;
        } catch (Exception ex) {
            if (tx != null) tx.rollback();
            ex.printStackTrace();
            return 0;
        }
    }
    
}
