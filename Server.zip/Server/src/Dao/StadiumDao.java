/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.Stadium;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;


public class StadiumDao {

    public StadiumDao() {
    }

    // Method to retrieve all stadiums
    public List<Stadium> retrieveStadiums() {
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            List<Stadium> query = session.createQuery("from Stadium").list();
            return query;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    // Method to delete a stadium
    public int deleteStadium(Stadium stadium) {
        Transaction tx = null;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            session.delete(stadium);
            tx.commit();
            return 1;
        } catch (Exception ex) {
            if (tx != null) tx.rollback();
            ex.printStackTrace();
            return 0;
        }
    }

    // Method to update a stadium
    public int updateStadium(Stadium stadium) {
        Transaction tx = null;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            session.update(stadium);
            tx.commit();
            return 1;
        } catch (Exception ex) {
            if (tx != null) tx.rollback();
            ex.printStackTrace();
            return 0;
        }
    }

    // Method to add a stadium
    public int addStadium(Stadium stadium) {
        Transaction tx = null;
        try  {
            Session session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            session.save(stadium);
            tx.commit();
            return 1;
        } catch (Exception ex) {
            if (tx != null) tx.rollback();
            ex.printStackTrace();
            return 0;
        }
    }
}
