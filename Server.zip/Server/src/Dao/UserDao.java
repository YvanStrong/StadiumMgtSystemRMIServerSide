package Dao;

import Model.Event;
import Model.Stadium;
import Model.UserDTO;
import java.util.HashMap;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;
import java.util.Map;

public class UserDao {
    private static Map<String, String> otpStorage = new HashMap<>();

    public int saveUser(UserDTO user) {
        Transaction transaction = null;
        try {Session session = HibernateUtil.getSessionFactory().openSession();
            transaction = session.beginTransaction();
            session.save(user);
            transaction.commit();
            return 1;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
            return 0;
        }
    }
public List<UserDTO> getAllUsers() {
    try {Session session = HibernateUtil.getSessionFactory().openSession();
        return session.createQuery("FROM UserDTO").list();
    } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
}
    public int deleteUser(UserDTO user) {
        Transaction tx = null;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            session.delete(user);
            tx.commit();
            return 1;
        } catch (Exception ex) {
            if (tx != null) tx.rollback();
            ex.printStackTrace();
            return 0;
        }
    }
    public UserDTO getUser(int id) {
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            return (UserDTO) session.get(UserDTO.class, id);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    // Method to update 
    public int updateUser(UserDTO user) {
        Transaction tx = null;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            session.update(user);
            tx.commit();
            return 1;
        } catch (Exception ex) {
            if (tx != null) tx.rollback();
            ex.printStackTrace();
            return 0;
        }
    }
    public UserDTO getUserByUsernameAndPassword(String username, String password) {
        try {Session session = HibernateUtil.getSessionFactory().openSession();
            List<UserDTO> users = session.createQuery("FROM UserDTO WHERE username = :username AND password = :password")
                    .setParameter("username", username)
                    .setParameter("password", password)
                    .list();

            if (!users.isEmpty()) {
                return users.get(0);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public boolean saveOtp(String username, String otp) {
       
        otpStorage.put(username, otp);
        return true;
    }

    public boolean verifyOtp(String username, String otp) {
        
        String storedOtp = otpStorage.get(username);
        return storedOtp != null && storedOtp.equals(otp);
    }
}
