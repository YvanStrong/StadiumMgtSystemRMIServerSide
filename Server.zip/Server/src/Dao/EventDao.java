package Dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;
import Model.Event;

public class EventDao {

    public EventDao() {
    }

    // Method to retrieve all events
    // In your EventImpl class or wherever the retrieveEvents method is implemented
public List<Event> retrieveEvents() {
    try {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Event> events = session.createQuery("from Event").list();
        session.clear(); // Detach all entities from the session
        return events;
    } catch (Exception ex) {
        ex.printStackTrace();
        return null;
    }
}


    // Method to find an event by ID
    public Event getEvent(int id) {
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            return (Event) session.get(Event.class, id);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    // Method to delete an event
    public int deleteEvent(Event event) {
        Transaction tx = null;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            session.delete(event);
            tx.commit();
            return 1;
        } catch (Exception ex) {
            if (tx != null) tx.rollback();
            ex.printStackTrace();
            return 0;
        }
    }

    // Method to update an event
    public int updateEvent(Event event) {
        Transaction tx = null;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            session.update(event);
            tx.commit();
            return 1;
        } catch (Exception ex) {
            if (tx != null) tx.rollback();
            ex.printStackTrace();
            return 0;
        }
    }

    // Method to add an event
    public int addEvent(Event event) {
        Transaction tx = null;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            session.save(event);
            tx.commit();
            return 1;
        } catch (Exception ex) {
            if (tx != null) tx.rollback();
            ex.printStackTrace();
            return 0;
        }
    }
}
